import PhantomHuntPage from "@/components/phantomhunt-page"

export default function Page() {
  return <PhantomHuntPage />
}
